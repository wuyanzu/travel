package T;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import com.jspsmart.upload.*;
import java.util.*;

public class TravelSite {
	
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	//登录界面跳转login
	public String loginChange() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String name=request.getParameter("username");
			String pw=request.getParameter("password");
			
			st=con.createStatement();
			String sql="select id,username,password from user_for_register";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				if(name.equals(rs.getString(2))) {
					if(pw.equals(rs.getString(3))) {
						result="login";
						session.setAttribute("userID", rs.getString(1));
					}else {
						result="stay";
					}
			}
			}
			st.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//注册用户
	public String registerChange() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String name=request.getParameter("username");
			String pw=request.getParameter("password");
			String email=request.getParameter("email");
			String question=request.getParameter("question");
			String answer=request.getParameter("answer");
			
			String sql="insert into user_for_register(username,password,email,question,answer)values('"+name+"','"+pw+"','"+email+"','"+question+"','"+answer+"')";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return result;
		
	}
	
	//修改密码
	public String updateChange() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String name=request.getParameter("username");
			String pw=request.getParameter("password");
			String question=request.getParameter("question");
			String answer=request.getParameter("answer");
			System.out.println(name+" "+pw);
			
			String sql="update user_for_register set password='"+pw+"'" +
					" where username='"+name+"' and question='"+question+"' and answer='"+answer+"'" +
							" or email='"+name+"' and question='"+question+"' and answer='"+answer+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//插入个人信息
	public String myInformation() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String userID=(String)session.getAttribute("userID");
			String name=request.getParameter("name");
			String sex=request.getParameter("sex");
			String age=request.getParameter("age");
			String home=request.getParameter("address");
			String career=request.getParameter("career");
			String hobby=request.getParameter("hobby");
			
			String sql="update user_info set name='"+name+"',sex='"+sex+"',age='"+age+"',home='"+home+"',career='"+career+"',hobby='"+hobby+"' where userID='"+userID+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//插入行程
	public String addTravel() {
		String result="stay";
		String date="1";
		String place=" 2";
		String sql="";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			date=request.getParameter("time");
			place=request.getParameter("endPoint");
			
			sql="insert into travel_history(userID,travelDate,place)values("+(String)session.getAttribute("userID")+",'"+date+"','"+place+"')";
			
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return result;
	}
	

}
