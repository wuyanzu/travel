package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForRegister implements UserRegister {
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	public String username="";
	public String pw="";
	public String email="";
	public String question="";
	public String answer="";
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	//创建用户，插入用户信息
	public String setUserInfo() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			username=request.getParameter("username");
			pw=request.getParameter("password");
			email=request.getParameter("email");
			question=request.getParameter("question");
			answer=request.getParameter("answer");
			
			String sql="insert into user_for_register(username,password,email,question,answer)values('"+username+"','"+pw+"','"+email+"','"+question+"','"+answer+"')";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//登录验证
	public String getUserInfo() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			username=request.getParameter("username");
			pw=request.getParameter("password");
			
			st=con.createStatement();
			String sql="select id,username,password from user_for_register";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				if(username.equals(rs.getString(2))) {
					if(pw.equals(rs.getString(3))) {
						result="login";
						session.setAttribute("userID", rs.getString(1));
					}else {
						result="stay";
					}
			}
			}
			st.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return result;
	}
	
	//更改密码
	public String updateUserInfo() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			username=request.getParameter("username");
			pw=request.getParameter("password");
			question=request.getParameter("question");
			answer=request.getParameter("answer");
			
			String sql="update user_for_register set password='"+pw+"'" +
					" where username='"+username+"' and question='"+question+"' and answer='"+answer+"'" +
							" or email='"+username+"' and question='"+question+"' and answer='"+answer+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
}
