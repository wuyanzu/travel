package tra;

public interface Diary {
	
	public String title="";
	public String text="";
	public String date="";
	
	public String setDiary();
	public String updateDiary();
	public String deleteDiary();

}
