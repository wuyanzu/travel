package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForMessage implements Message {
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	public String sendUserName="";
	public String getUserName="";
	public String sendUserID="";
	public String getUserID="";
	public String message="";
	
	//保存聊天信息
	public String addMessage(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			Date dt=new Date();
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String nowDate=df.format(dt);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			sendUserID=(String)session.getAttribute("userID");
			getUserID=(String)session.getAttribute("friendID");
			message=request.getParameter("mess");
			String s1="select username from user_for_register where id='"+sendUserID+"'";
			String s2="select username from user_for_register where id='"+getUserID+"'";
			st=con.createStatement();
			ResultSet rs1=st.executeQuery(s1);
			while(rs1.next()) {
				sendUserName=rs1.getString(1);
			}
			Statement st1=con.createStatement();
			ResultSet rs2=st1.executeQuery(s2);
			while(rs2.next()) {
				getUserName=rs2.getString(1);
			}
			
			String s3="select sendUserID, getUserID, flag from invite_message";
			Statement st3=con.createStatement();
			ResultSet rs3=st3.executeQuery(s3);
			while(rs3.next()){
				if(rs3.getString(2).equals(sendUserID) && rs3.getString(1).equals(getUserID) && rs3.getString(3).equals("0") ){							
							String s4 = "update invite_message set flag=1 where sendUserID='"+getUserID+"' and getUserID='"+sendUserID+"'";
							PreparedStatement st4=con.prepareStatement(s4);
							st4.execute();	
							st4.close();
				}
			}
			
			String sql="insert into invite_message(sendUserID,getUserID,sendUserName,getUserName,message,time)values('"+sendUserID+"','"+getUserID+"','"+sendUserName+"','"+getUserName+"','"+message+"','"+nowDate+"')";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			st.close();
			st1.close();
			st3.close();
			ps.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		
		return "success";
	}
	
	//删除聊天信息
	public String deleteMessage() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			sendUserID=(String)session.getAttribute("userID");
			getUserID=(String)session.getAttribute("friendID");
			
			String sql="delete from invite_message where sendUserID='"+sendUserID+"' and getUserID='"+getUserID+"' or sendUserID='"+getUserID+"' and getUserID='"+sendUserID+"'";
			
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		
		return "success";
	}
	
	//选择操作
	public String messageOper() {
		String result="success";
		UserForMessage um=new UserForMessage();
		try{
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String oper=request.getParameter("messOper");
			if(oper!=null) {
				if(oper.equals("删除聊天记录")) {
					result=um.deleteMessage();
				}else {
					result=um.addMessage();
				}
			}else {
				result="stay";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
