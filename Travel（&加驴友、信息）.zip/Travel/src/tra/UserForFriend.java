package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForFriend implements Friend{
	
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	public String friendName="";
	public String email="";
	
	//删除好友
	public String deleteFriend(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String friendID=request.getParameter("fri");
			
			String sql="delete from donkey_friend where userID='"+(String)session.getAttribute("userID")+"' and friendID='"+friendID+"'";
			String sql1="delete from invite_message where sendUserID='"+(String)session.getAttribute("userID")+"' and getUserID='"+friendID+"' or sendUserID='"+friendID+"' and getUserID='"+(String)session.getAttribute("userID")+"'";
			String sql2="delete from donkey_friend where userID='"+friendID+"' and friendID='"+(String)session.getAttribute("userID")+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps=con.prepareStatement(sql1);
			ps.executeUpdate(sql1);
			ps=con.prepareStatement(sql2);
			ps.executeUpdate(sql2);
			ps.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		
		return "success";
	}
	
	//选择操作
	public String friendOper() {
		String result="stay";
		UserForFriend uf=new UserForFriend();
		try{
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			
			String oper=request.getParameter("friOper");
			if(oper!=null){
				if(oper.equals("删除好友")) {
					result=uf.deleteFriend();
				}else {
					result="sendMessage";
				}
			}else {
				result="stay";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
