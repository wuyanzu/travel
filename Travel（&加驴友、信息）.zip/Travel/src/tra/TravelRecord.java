package tra;

public interface TravelRecord {
	
	public String userID="";
	public String travelDate="";
	public String place="";
	
	public String getRecord();
	public String deleteRecord();
	public String setRecord();

}
