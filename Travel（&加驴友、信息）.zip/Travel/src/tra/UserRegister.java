package tra;

public interface UserRegister {
	
	public String username="";
	public String pw="";
	public String email="";
	public String question="";
	public String answer="";
	
	public String setUserInfo();
	public String getUserInfo();
	public String updateUserInfo();

}
