package tra;

public interface UserPriInfo {
	public String userID="";
	public String name="";
	
	public String updatePriInfo();
	public String getPriInfo();
}
