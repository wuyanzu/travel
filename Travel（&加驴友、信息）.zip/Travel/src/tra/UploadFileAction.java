package tra;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.sun.jmx.snmp.Timestamp;
public class UploadFileAction extends ActionSupport{
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	Connection con=null;
	PreparedStatement ps=null;
	
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	private File uploadFile;
	private String uploadFileContentType;
	private String uploadFileName;
	
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile){
		this.uploadFile=uploadFile;
	}
	public String getUploadFileContentType(){
		return uploadFileContentType;
	}
	public void setUploadFileContentType(String uploadFileContentType){
		this.uploadFileContentType = uploadFileContentType;
	}
	public String getUploadFileName(){
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName){
		this.uploadFileName = uploadFileName;
	}
	public String upload() throws Exception{
		String realpath = ServletActionContext.getServletContext().getRealPath("/images");
		//System.out.println(ServletActionContext.getServletContext().getRealPath("/"));
		File dir = new File(realpath);
		if (!dir.exists()){
			dir.mkdir();
		}
		if(uploadFileContentType.equals("image/jpeg")){
			uploadFileContentType=".jpg";
		}
		else if(uploadFileContentType.equals("image/png")){
			uploadFileContentType=".png";
		}
		else if(uploadFileContentType.equals("image/gif")){
			uploadFileContentType=".gif";
		}
		uploadFileName="image"+(String)session.getAttribute("userID")+uploadFileContentType;
		FileUtils.copyFile(uploadFile, new File(dir, uploadFileName));
		String picPath="images/"+uploadFileName;
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			String sql="update user_info set picture='"+picPath+"' where userID='"+(String)session.getAttribute("userID")+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
		}catch(Exception se) {
			se.printStackTrace();
		}
		
		return SUCCESS;
	}
}

