package tra;

public interface Message {
	public String sendUserName="";
	public String getUserName="";
	public String sendUserID="";
	public String getUserID="";
	public String message="";
	public String addMessage();
	public String deleteMessage();

}
