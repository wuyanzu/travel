package tra;

public interface Friend {
	public String friendName="";
	public String email="";
	public String deleteFriend();
}
