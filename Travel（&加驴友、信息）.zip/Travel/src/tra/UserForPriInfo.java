package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForPriInfo implements UserPriInfo{
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	public String userID="";
	public String name="";
	private String sex;
	private String age;
	private String home;
	private String career;
	private String hobby;
	
	//完善个人信息
	public String updatePriInfo() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			userID=(String)session.getAttribute("userID");
			name=request.getParameter("name");
			sex=request.getParameter("sex");
			age=request.getParameter("age");
			home=request.getParameter("address");
			career=request.getParameter("career");
			hobby=request.getParameter("hobby");
			
			String sql="update user_info set name='"+name+"',sex='"+sex+"',age='"+age+"',home='"+home+"',career='"+career+"',hobby='"+hobby+"' where userID='"+userID+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//获取个人信息
	public String getPriInfo() {
		return "success";
	}
	
}
