package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForTraRecord implements TravelRecord {
	
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	public String userID="";
	public String travelDate="";
	public String place="";
	
	//获取旅游记录
	public String getRecord(){
		return "s";
	}
	
	//删除旅游记录
	public String deleteRecord() {
		return "s";
	}
	
	//设置旅游行程
	public String setRecord() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			travelDate=request.getParameter("time");
			place=request.getParameter("endPoint");
			
			String sql="insert into travel_history(userID,travelDate,place)values("+(String)session.getAttribute("userID")+",'"+travelDate+"','"+place+"')";
			
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="success";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
}
