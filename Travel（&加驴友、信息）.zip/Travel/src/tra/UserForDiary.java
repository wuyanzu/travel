package tra;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

public class UserForDiary implements Diary{
	
	PreparedStatement ps=null;
	Statement st=null;
	Connection con=null;
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response=ServletActionContext.getResponse();
	HttpSession session=request.getSession();
	
	String url="jdbc:mysql://localhost:3306/lab";
	String user="root";
	String password="580271";
	
	public String title="";
	public String text="";
	public String date="";
	String pro="";
	String sceneryname="";
	
	//设置日志信息
	public String setDiary() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			title=request.getParameter("title");
			pro=request.getParameter("province");
			text=request.getParameter("content");
			sceneryname=request.getParameter("attraction");
			
			Date dt=new Date();
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
			String nowDate=df.format(dt);
			
			String sql="insert into diary(userID,article,province,title,sceneryName,state,date)values('"+(String)session.getAttribute("userID")+"'," +
					"'"+text+"','"+pro+"','"+title+"','"+sceneryname+"',0,'"+nowDate+"')";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="set";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//设置分享的信息
	public String setShareDiary() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			title=request.getParameter("title");
			pro=request.getParameter("province");
			text=request.getParameter("content");
			sceneryname=request.getParameter("attraction");
			
			Date dt=new Date();
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String nowDate=df.format(dt);
			String cont="";
			String diID="";
			
			String sql="insert into diary(userID,article,province,title,sceneryName,state,date)values('"+(String)session.getAttribute("userID")+"'," +
					"'"+text+"','"+pro+"','"+title+"','"+sceneryname+"',1,'"+nowDate+"')";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			String sql1="select max(id) from diary where userID='"+(String)session.getAttribute("userID")+"'";
			st=con.createStatement();
			ResultSet rs=st.executeQuery(sql1);
			while(rs.next()) {
				diID=rs.getString(1);
			}
			String sql2="insert into diaryContent(diaryID,content,prize)values('"+diID+"','"+cont+"',0)";
			ps=con.prepareStatement(sql2);
			ps.executeUpdate(sql2);
			ps.close();
			st.close();
			con.close();
			result="set";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//更新日志信息
	public String updateDiary() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			title=request.getParameter("title");
			pro=request.getParameter("province");
			text=request.getParameter("content");
			sceneryname=request.getParameter("attraction");
			
			String sql="update diary set title='"+title+"',province='"+pro+"',article='"+text+"',sceneryName='"+sceneryname+"' where id='"+(String)session.getAttribute("diaryID")+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="update";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//删除日志信息
	public String deleteDiary() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			
			String sql="delete from diary where id='"+(String)session.getAttribute("diaryID")+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
			result="delete";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	public String shareDiary() {
		String result="stay";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			
			title=request.getParameter("title");
			pro=request.getParameter("province");
			text=request.getParameter("content");
			sceneryname=request.getParameter("attraction");
			String cont="";
			
			String sql="update diary set title='"+title+"',province='"+pro+"',article='"+text+"',sceneryName='"+sceneryname+"',state=1 where id='"+(String)session.getAttribute("diaryID")+"'";
			String sql1="insert into diaryContent(diaryID,content,prize)values('"+(String)session.getAttribute("diaryID")+"','"+cont+"',0)";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps=con.prepareStatement(sql1);
			ps.executeUpdate(sql1);
			ps.close();
			con.close();
			result="share";
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return result;
	}
	
	//判断日志操作
	public String operation() {
		UserForDiary ud=new UserForDiary();
		String result="stay";
		try{
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			
			String oper=request.getParameter("choose");
			if(session.getAttribute("diaryID")==null&&oper!=null) {
				if(oper.equals("save")) {
					result=ud.setDiary();
				}else if(oper.equals("share")) {
					result=ud.setShareDiary();
				}else {
					result="set";
				}
			}else if(session.getAttribute("diaryID")!=null&&oper!=null) {
				if(oper.equals("save")) {
					result=ud.updateDiary();
				}else if(oper.equals("delete")) {
					result=ud.deleteDiary();
				}else
					result=ud.shareDiary();
			}else {
				result="stay";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
}
	
	//发表日志评论
	public String diaryCon() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			st=con.createStatement();
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String uName="";
			String sq="select name from user_info where userID='"+(String)session.getAttribute("userID")+"'";
			ResultSet rs=st.executeQuery(sq);
			while(rs.next()) {
				uName=rs.getString(1);
			}
			String cont=uName+":"+request.getParameter("setCon");
			String dID=request.getParameter("diaryID");
			
			String sql="insert into diaryContent(diaryID,content,prize)values('"+dID+"','"+cont+"',0)";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			st.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return "success";
	}
	
	//点赞
	public String diaryPrize() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,user,password);
			
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			String dID=request.getParameter("diaryID");
			
			String sql="update diaryContent set prize=prize+1 where diaryID='"+dID+"'";
			ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			ps.close();
			con.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(ClassNotFoundException cn) {
			cn.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} 
		return "success";
	}
	
	//选择日志评论操作
	public String conOper() {
		String dID=request.getParameter("diaryID");
		String oper=request.getParameter("operCon"+dID);
		UserForDiary ud=new UserForDiary();
		
		String s="success";
		try{
			response.setCharacterEncoding("UTF-8");
			request.setCharacterEncoding("UTF-8");
			response.setContentType("text/html;charset=UTF-8");
			
			if(oper!=null) {
				if(oper.equals("发表评论")) {
					s=ud.diaryCon();
				}else{
					s=ud.diaryPrize();
				}
			}else {
				s="success";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return s;
	}
}
