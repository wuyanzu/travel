package tra;

public interface Scenery {
	
	public String sceneryName="";
	public String province="";
	public String description="";
	public String picture="";
	
	public String getScenery();
	

}
